import express from 'express'; import cors from 'cors';
const app = express(); app.use(cors()); app.use(express.json());

app.post('/api/estimate', (req, res) => res.json({ estimate: 5000000, explanation: 'Eksempel', adresse: 'Testveien 1' }));
app.post('/api/neighborhood', (req, res) => res.json({ trygghet: 8.2, skole: 7.1, stoy: 3.5, kollektiv: 9.3, prisvekst: 4.7 }));
app.post('/api/rent', (req, res) => res.json({ snittleie: 14500, breakEvenAar: 12, avkastningProsent: 5.6 }));
app.post('/api/whatif', (req, res) => res.json({ nyVerdi: 5200000, verdiøkning: 400000 }));
app.post('/api/compare', (req, res) => res.json([{ adresse: 'A', pris: 4900000 }, { adresse: 'B', pris: 5300000 }]));
app.post('/api/subscribe', (req, res) => res.json({ success: true }));

app.listen(4000, () => console.log('Backend kjører på http://localhost:4000'));