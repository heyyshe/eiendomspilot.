# EiendomsPilot

Komplett prosjekt med frontend (React + Tailwind) og backend (Express).

## Kjøring:

**Frontend**
```
cd frontend
npm install
npm run dev
```

**Backend**
```
cd backend
npm install
node server.js
```

## Endepunkter:
- /api/estimate
- /api/neighborhood
- /api/rent
- /api/whatif
- /api/compare
- /api/subscribe